package com.rabbitmq.assignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RabbitmqAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
