package com.rabbitmq.assignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RabbitmqAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(RabbitmqAssignmentApplication.class, args);
	}

}
