package com.example.demo.order;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString

@Document(collation = "Oders")
public class Orders {
	@Id
    private int id;
    private String orderName;
    private String oderDiscription;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getOrderName() {
		return orderName;
	}
	public void setOrderName(String orderNmae) {
		this.orderName = orderNmae;
	}
	public String getOderDiscription() {
		return oderDiscription;
	}
	public void setOderDiscription(String oderDiscription) {
		this.oderDiscription = oderDiscription;
	}
	@Override
	public String toString() {
		return "Orders [id=" + id + ", orderNmae=" + orderName + ", oderDiscription=" + oderDiscription + "]";
	}
    
}
