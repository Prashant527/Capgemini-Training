package com.example.demo.orderRepository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.demo.order.Orders;

public interface OrderRepository extends MongoRepository<Orders, Integer> {

}
