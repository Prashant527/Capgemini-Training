package com.example.demo.orderController;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.order.Orders;
import com.example.demo.orderRepository.OrderRepository;

@RestController
public class OrderController {
	@Autowired
	private OrderRepository orderRepository;
	@RequestMapping("/order")
	public String addOrder(@RequestBody Orders orders) {
		orderRepository.save(orders);
		return "Order Added:"+orders.getId();
	}
	@RequestMapping("/Allorder")
	public List<Orders> getAllOrders() {
		return orderRepository.findAll();
	}
	@RequestMapping("/Allorder/{id}")
	public Optional<Orders> getOrdersById(@PathVariable int id){
		return orderRepository.findById(id);
	}
	@RequestMapping("/delteorder")
	public String deleteOrders() {
		orderRepository.deleteAll();
		return "Oders Deleted";
	}
 
}
