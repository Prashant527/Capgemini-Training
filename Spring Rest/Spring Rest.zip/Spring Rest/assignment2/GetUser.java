package com.springrest.assignment2;

public class GetUser extends User {
 public User getUser() {
	 User u1=new User();
	 u1.setEmail("rahul");
	 u1.setPassword("rahul");
	 return u1;
 }
}
