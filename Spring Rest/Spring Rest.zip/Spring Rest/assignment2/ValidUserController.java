package com.springrest.assignment2;


import java.util.Arrays;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ValidUserController {
	@ResponseBody
	@RequestMapping(value="/print",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public List<User> getemployee() {
		return Arrays.asList(
				new User("Rahul@gmail","Rahul"),
				new User("Rohit@yahoo","Rohit"));			
	}
	
	

}
