package com.springrest.assignment3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AddressController {
	
		@RequestMapping(value = "/country/{zipcode}", method = RequestMethod.GET,headers="Accept=application/json")
	    public Address getCountryById(@PathVariable int zipcode){
	        List<Address> listOfCountries = new ArrayList<Address>();
	        listOfCountries=createCountryList();
	 
	        for (Address country: listOfCountries) {
	            if(country.getZipcode()==zipcode)
	                return country;
	        }
	 
	        return null;
	    }
		@RequestMapping("/getCountry")
		public Address getCountry(@RequestParam("code") String zcode) {
			long zipcode = Integer.parseInt(zcode);
			List<Address> listOfCountries = new ArrayList<Address>();
	        listOfCountries=createCountryList();
	 
	        for (Address country: listOfCountries) {
	            if(country.getZipcode()==zipcode)
	                return country;
	        }
	 
	        return null;
		}
		
		public List<Address> createCountryList(){
		        Address c1=new Address(500124, "Telangana","Hyderabad","India");
		        Address c2=new Address(265622, "AnyState","anycity", "Japan");
		        Address c3=new Address(199522, "West Virginia","ClownTown", "US");
		        Address c4=new Address(651652, "AnyState","anycity", "Canada");
		 
		        List<Address> listOfCountries = new ArrayList<Address>();
		        listOfCountries.add(c1);
		        listOfCountries.add(c2);
		        listOfCountries.add(c3);
		        listOfCountries.add(c4);
		        return listOfCountries;
		}
	
}
