//1) Create a RESTful web service that returns "Hello World" message.

package com.springrest.assignment1;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HelloWorld {
	  @ResponseBody
      @RequestMapping("/hey")
      public String greeting() {
    	  return "Hello World!";
      }
}
