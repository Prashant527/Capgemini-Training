package com.springrest.assignment9;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {
	@Autowired
     private CustomerService customerService;
	
	@RequestMapping("/customer")
	public List<Customer> getAllCustomers(){
		return customerService.getAllCustomers();
		
	}
	@RequestMapping("/customer/{customerId}")
	public Customer getAllCustomers(@PathVariable String customerId){
		return customerService.getCustomer(customerId);
		
	}
	@RequestMapping(value="/customer",method = RequestMethod.POST)
	public void addCustomer(@RequestBody Customer customer){
		customerService.addCustomer(customer);
	}
	@RequestMapping(value="/customer/{customerId}",method = RequestMethod.PUT)
	public void updateCustomer(@RequestBody Customer customer,@PathVariable String customerId){
		customerService.updateCustomer(customerId,customer);
	}
	@RequestMapping(value="/customer/{customerId}",method = RequestMethod.DELETE)
	public void deleteCustomer(@PathVariable String customerId){
		customerService.deleteCustomer(customerId);
	}
	
}
