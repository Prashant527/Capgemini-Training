package com.springrest.assignment9;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;
@Service
public class CustomerService {
	
	private List<Customer> customers=new ArrayList<>(Arrays.asList(
			new Customer("1","mohan","Branch Manager"),
			new Customer("2","sohan","employee")
			));
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customers;
	}

	public void addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		customers.add(customer);
	}

	public Customer getCustomer(String customerId) {
		// TODO Auto-generated method stub
		return customers.stream().filter(x -> x.getCustomerId().equals(customerId)).findFirst().get();
	}

	public void updateCustomer(String customerId, Customer customer) {
		// TODO Auto-generated method stub
		
	}

	public void deleteCustomer(String customerId) {
		// TODO Auto-generated method stub
		customers.removeIf(x->x.getCustomerId().equals(customerId));
	}
	

}
