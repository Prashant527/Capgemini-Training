package com.springrest.assignment9;

public class Customer {
    private String customerId;
    private String customerName;
    private String customerDeatils;
    public Customer() {
    	
    }
	public Customer(String customerId, String customerName, String customerDeatils) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerDeatils = customerDeatils;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerDeatils() {
		return customerDeatils;
	}
	public void setCustomerDeatils(String customerDeatils) {
		this.customerDeatils = customerDeatils;
	}
    
}
