package com.springrest.assignment6;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CalculatorController {
		@RequestMapping("/add")
		public int getaddition() {
			Calculator calculate=new Calculator();
			calculate.setNum1(10);
			calculate.setNum2(20);
			return calculate.add();
			
		}
		@RequestMapping("/sub")
		public int getsubstract() {
			Calculator calculate=new Calculator();
			calculate.setNum1(40);
			calculate.setNum2(20);
			return calculate.sub();
			
		}
		@RequestMapping("/mul")
		public int getmultiply() {
			Calculator calculate=new Calculator();
			calculate.setNum1(10);
			calculate.setNum2(20);
			return calculate.mul();
			
		}
		@RequestMapping("/div")
		public int getDivide() {
			Calculator calculate=new Calculator();
			calculate.setNum1(20);
			calculate.setNum2(20);
			return calculate.div();
			
		}
			
}
