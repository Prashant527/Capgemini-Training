package com.springrest.assignment5;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {
	 private List<Employee> employees= new ArrayList<>(Arrays.asList(
	    		new Employee(1,"rohan","cse","manager",20000.0),
	    		new Employee(2,"rahul","ece","developer",40000.0),
	    		new Employee(3,"rohit","cse","junior manager",10000.0)
	    		));
	 @RequestMapping(value = "/employees", method = RequestMethod.GET,headers="Accept=application/json")
	    public List<Employee> getAllEmployees(){
	    	return employees;
	 }
	 @RequestMapping(value = "/employees/{EmployeeId}", method = RequestMethod.GET,headers="Accept=application/json")
	    public Employee getEmployeeById(@PathVariable int employeeId){
	       return employees.get(employeeId);
	    }
	 @RequestMapping(value = "/employees", method = RequestMethod.DELETE,headers="Accept=application/json")
	    public void deleteEmployee(int employeeId) {
	    	employees.remove(employeeId);
	    }
}
