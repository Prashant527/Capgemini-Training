package com.springboot.courseapi;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorld {
	@RequestMapping("/")
	public String print() {
		//return "Hello World!";
		return "Welcome";
	}
	@RequestMapping("/admin")
	public String print1() {
		return "Welcome Admin";
	}
	@RequestMapping("/user")
	public String print2() {
		return "Welcome User";
	}

}
