package com.springboot.jdbc.springbootsecurityjdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSecurityJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
