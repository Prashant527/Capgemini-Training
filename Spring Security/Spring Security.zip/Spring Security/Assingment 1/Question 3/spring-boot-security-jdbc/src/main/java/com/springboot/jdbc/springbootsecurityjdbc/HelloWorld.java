package com.springboot.jdbc.springbootsecurityjdbc;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorld {
	@GetMapping("/")
	public String print() {
		//return "Hello World!";
		return "Welcome";
	}
	@GetMapping("/admin")
	public String print1() {
		return "Welcome Admin";
	}
	@GetMapping("/user")
	public String print2() {
		return "Welcome User";
	}

}

