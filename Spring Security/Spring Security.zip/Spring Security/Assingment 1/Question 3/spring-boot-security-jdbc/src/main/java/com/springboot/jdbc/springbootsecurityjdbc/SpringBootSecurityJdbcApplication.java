package com.springboot.jdbc.springbootsecurityjdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSecurityJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSecurityJdbcApplication.class, args);
	}

}
