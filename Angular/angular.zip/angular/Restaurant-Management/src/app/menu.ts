export const ELEMENT_DATA= [
    {position: 2, name: 'Tandoori Ghobi Tikka', price:80 }, 
    {position: 3, name: 'Tandoori Aloo', price: 80, },
    {position: 4, name: 'Tandoori Tikka', price: 100, },
    {position: 5, name: 'Tandoori Paneer Tikka', price: 110, },
    {position: 6, name: 'Soya Chaap', price: 120, }, 
    {position: 7, name: 'Veg Sizzler', price: 150, },
    {position: 8, name: 'Indian Sizzler', price:160, },
    {position: 9, name: 'Chinese Sizzler', price: 160, },
    {position: 10, name: 'Veggie Burger', price: 40, },
  ];