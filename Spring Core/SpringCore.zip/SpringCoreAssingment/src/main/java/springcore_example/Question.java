package springcore_example;

import java.util.List;

public class Question {
	
	List<SupportQuestion> Answer;
	
	
	public List<SupportQuestion> getAnswer() {
		return Answer;
	}


	public void setAnswer(List<SupportQuestion> answer) {
		Answer = answer;
	}


	public void method() {
		for(SupportQuestion answer:Answer)
		System.out.println(answer.getAnswers() );
	}

}
