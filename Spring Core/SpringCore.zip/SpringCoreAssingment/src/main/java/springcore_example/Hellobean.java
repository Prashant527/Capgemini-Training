package springcore_example;

public class Hellobean {
   private String name;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
   public void sayHello() {
	   System.out.println(this.name + " Hello!");
   }
}
