package springcore_example;

public interface Shape {
   public void draw();
}
