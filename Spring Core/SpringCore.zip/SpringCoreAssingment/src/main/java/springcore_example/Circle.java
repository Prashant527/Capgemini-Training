package springcore_example;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
@Service  //it informs spring.xml that this is a service bean.
@Component    // <bean id="circle" class="springcore_example.Circle"></bean>  
@Repository //it tells spring.xml that it a data object.
@Controller  //it for MVC pattern.
public class Circle implements Shape {
	private Point center;
	
	public Point getCenter() {
		return center;
	}
	//@Autowire
    //@Resource(name="pointC")
	//@Qualifier("circle related")
	public void setCenter(Point center) {
		this.center = center;
	}
	//@Override
    public void draw() {
		System.out.println("center"+ center.getX()+","+center.getY());
	}
   //@PostConstruct
    public void init() {
    	System.out.println("intializing a circle");
    }
    //@PreDestroy
    public void destroy() {
    	System.out.println("destroying a circle");
    }
   

}
