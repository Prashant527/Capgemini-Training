package springcore_example;

public class BankAccountepositoryImpl implements BankAccountRepository {

	public double getBalance(long accountId) {
		return getBalance(accountId);
	}

	public double updateBalance(long accountId, double newBalance) {
		return  updateBalance(accountId, newBalance);
	}

}
