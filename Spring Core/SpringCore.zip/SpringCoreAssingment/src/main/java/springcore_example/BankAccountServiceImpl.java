package springcore_example;

public class BankAccountServiceImpl implements BankAccountService {

	public double withdraw(long accountId, double balance) {
		// TODO Auto-generated method stub
		return 0;
	}

	public double deposit(long accountId, double balance) {
		// TODO Auto-generated method stub
		return 0;
	}

	public double getBalance(long accountId) {
		// TODO Auto-generated method stub
		return 0;
	}

	public boolean fundTransfer(long fromAccount, long toAccount, double amont) {
		// TODO Auto-generated method stub
		return false;
	}

}
