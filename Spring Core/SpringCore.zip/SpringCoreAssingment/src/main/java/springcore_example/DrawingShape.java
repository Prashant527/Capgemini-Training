/*
4) Example on @Controller, @Service, @Repository, @Autowired, @Configuration and @Bean
Modify the above application, use annotations and java based configuration.
5) Write a program to demonstrate use of @Resource, @Inject, @Required annotations
6) Example of @Component, @Value, @PropertySource & Environment
a. Create a dbConfig.properties file which contains database configuration details like driver class name, dburl, username, password.
b. Create a Java class in which you have to read all properties and display on a console. (Use @Component, @Value or Environment and @PropertyResource).
7) Write a Java program to demonstrate SPEL (Spring Expression language)
8) Write a Java program to demonstrate InitializingBean and DisposableBean.
Try Different ways:
(Use init-method and destroy-method in xml config file)
(Use @PostConstruct and @PreDestroy)
9)Write a Java program to demonstrate Complete Bean Life cycle.
 */

package springcore_example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawingShape {
	private static AbstractApplicationContext context;
	public static void main(String[] args) {
	    context =new ClassPathXmlApplicationContext("spring.xml");
	    context.registerShutdownHook();//creating for postCOnstruct and PreDestroy(annotation).
		Triangle triangle=(Triangle) context.getBean("triangle");
		triangle.draw();
		Circle circle=(Circle) context.getBean("circle");
		circle.draw();
	
	}

}
