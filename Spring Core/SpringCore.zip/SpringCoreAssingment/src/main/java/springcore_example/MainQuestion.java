package springcore_example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainQuestion {
	private static ApplicationContext context;
	public static void main(String[] args) {
	    context =new ClassPathXmlApplicationContext("spring1.xml");
	    Question question=(Question) context.getBean("Question");
	    question.method();
	}
}
