package com.springmvc.studentcontroller;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class Customer {
	@NotNull
	@Pattern(regexp = "[^0-9]*")
	@Size(min=8,max=20,message = "Please Enter the user name between {min} to {max} characters.")
	private String username;
	@NotNull
	@Size(min=8,max=20,message="Please Enter The Strong Password of minmum length upto {min} characters.")
	private int password;
	@NotNull
	private String email;
	@NotNull
	@Size(min=10,max=10)
	private long contact;
	private String city;
	@NotNull
	@Size(min=6,max=6)
	private int zip;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getPassword() {
		return password;
	}
	public void setPassword(int password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getZip() {
		return zip;
	}
	public void setZip(int zip) {
		this.zip = zip;
	}

}
