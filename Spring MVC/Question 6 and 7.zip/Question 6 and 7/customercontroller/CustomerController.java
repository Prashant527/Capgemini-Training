package com.springmvc.studentcontroller;

import javax.validation.Valid;

//import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CustomerController {
	@RequestMapping(value="/addmissionForm.html",method = RequestMethod.GET)
	public ModelAndView getAddmissionForm() {
		ModelAndView model=new ModelAndView("AddmissionForm");
		return model;
	}
	@RequestMapping(value="/submitAdmissionForm.html",method = RequestMethod.POST)
	public ModelAndView SubmitAddmissionForm(@Valid @ModelAttribute("c1")Customer c1, 
			BindingResult result) {
        if(result.hasErrors()) {
        	ModelAndView model=new ModelAndView("AddmissionForm");
        	return model;
        }
		ModelAndView model=new ModelAndView("AddmissionSuccess");
		model.addObject("msg", "Customers details:-");
		return model;
	}
	
	

}
