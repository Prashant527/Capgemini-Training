package com.springmvc.employeeController;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class EmployeeController {
	private static List<Employee> list = new ArrayList<>();
	static {
		list.add(new Employee(1,"Chetan",80000.0));
		list.add(new Employee(2,"Bibek",90000.0));
		list.add(new Employee(3,"Mithlesh",20000.0));
		list.add(new Employee(4,"Rishab",70000.0));
		list.add(new Employee(5,"Raj",80000.0));
		list.add(new Employee(6,"Rahul",40000.0));
	}
	@RequestMapping(value="/link", method=RequestMethod.GET)
	public ModelAndView getemployee() {
		EmployeeList employeelist=new EmployeeList();
		employeelist.setList(list);
		return new ModelAndView("index1");
	
	}
	@RequestMapping(value="/showAllEmployee.html")
	public ModelAndView showAll(@ModelAttribute("employeelist")EmployeeList employeelist, List<Employee> list) {
		System.out.println(employeelist.getList());
		List<Employee> employee1 = employeelist.getList();
	
		if(null != employee1 && employee1.size() > 0) {
			EmployeeController.list= list;
			for (Employee employee : list) {
				System.out.printf(employee.getId()+" "+employee.getName()+" "+employee.getSalary() );
			}
		}
		return new ModelAndView("showAllEmployee");
		
		
	}
}
